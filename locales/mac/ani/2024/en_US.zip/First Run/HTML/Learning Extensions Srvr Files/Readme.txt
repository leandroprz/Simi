The files in this folder (and subfolder) are used for 
integrating Flash content with AICC-compliant Learning 
Management Systems (LMS).  These files need to be 
copied to the Web Server in the same folder as the 
Flash content to properly track to an AICC-compliant 
LMS.

For more information and instructions on how to use
these files, visit http://www.macromedia.com/support/flash