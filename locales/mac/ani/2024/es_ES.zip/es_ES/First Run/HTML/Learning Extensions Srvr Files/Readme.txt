Los archivos de esta carpeta (y subcarpeta) se utilizan para 
integrar el contenido de Flash con sistemas LMS 
(Learning Management Systems) compatibles con AICC. Estos archivos deben 
copiarse en el servidor Web en la misma carpeta que el 
contenido de Flash para realizar un seguimiento correcto 
en un sistema LMS compatible con AICC.

Para obtener m�s informaci�n e instrucciones sobre la utilizaci�n de
estos archivos, visite http://www.macromedia.com/support/flash